<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
    body {
        height: 842px;
        width: 595px;
        /* to centre page on screen*/
        margin-left: auto;
        margin-right: auto;
    }
</style>
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
.MsoChpDefault
	{font-family:"Calibri",sans-serif;}
.MsoPapDefault
	{margin-bottom:8.0pt;
	line-height:107%;}
@page WordSection1
	{size:595.45pt 841.7pt;
	margin:1.0in 1.0in 1.0in 56.9pt;}
div.WordSection1
	{page:WordSection1;}
-->
</style>

</head>

<body lang=EN-US style='word-wrap:break-word'>

<div class=WordSection1>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=642
 style='width:481.25pt;border-collapse:collapse;border:none'>
 <tr style='height:89.65pt'>
  <td width=83 valign=top style='width:62.1pt;padding:0in 5.4pt 0in 5.4pt;
  height:89.65pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'> <span lang=IN style='color:black'> `          </span></span></p>
  <p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
  font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
  font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
  font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>
  </td>
  <td width=284 valign=top style='width:212.65pt;padding:0in 5.4pt 0in 5.4pt;
  height:89.65pt'>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>   </span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  </td>
  <td width=275 valign=top style='width:206.5pt;padding:0in 5.4pt 0in 5.4pt;
  height:89.65pt'>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>Kepada :</span></p>
  </td>
 </tr>
 <tr style='height:7.55pt'>
  <td width=83 valign=top style='width:62.1pt;padding:0in 5.4pt 0in 5.4pt;
  height:7.55pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif;color:black'>Nomor</span></p>
  </td>
  <td width=284 valign=top style='width:212.65pt;padding:0in 5.4pt 0in 5.4pt;
  height:7.55pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif;color:black'>:</span><span style='font-size:12.0pt;
  line-height:115%;font-family:"Times New Roman",serif;color:black'> </span></p>
  </td>
  <td width=275 valign=top style='width:206.5pt;padding:0in 5.4pt 0in 5.4pt;
  height:7.55pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif;color:black'>Yth. Kepala </span><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>Kantor Kementrian Agama </span></p>
  </td>
 </tr>
 <tr style='height:18.9pt'>
  <td width=83 valign=top style='width:62.1pt;padding:0in 5.4pt 0in 5.4pt;
  height:18.9pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif;color:black'>Lampiran</span></p>
  </td>
  <td width=284 valign=top style='width:212.65pt;padding:0in 5.4pt 0in 5.4pt;
  height:18.9pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif;color:black'>: </span><span lang=IN style='font-size:
  12.0pt;line-height:115%;font-family:"Times New Roman",serif;color:black'>-</span></p>
  </td>
  <td width=275 valign=top style='width:206.5pt;padding:0in 5.4pt 0in 5.4pt;
  height:18.9pt'>
  <p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
  font-family:"Times New Roman",serif;color:black'>      </span><span
  lang=IN style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>Kediri</span></p>
  </td>
 </tr>
 <tr style='height:36.95pt'>
  <td width=83 valign=top style='width:62.1pt;padding:0in 5.4pt 0in 5.4pt;
  height:36.95pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif;color:black'>Perihal</span></p>
  </td>
  <td width=284 valign=top style='width:212.65pt;padding:0in 5.4pt 0in 5.4pt;
  height:36.95pt'>
  <p class=MsoNormal style='margin-left:8.8pt;text-indent:-8.8pt'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>: Pe</span><span lang=IN style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman",serif;color:black'>rmohonan Rekomendasi</span></p>
  <p class=MsoNormal style='margin-left:8.8pt;text-indent:-8.8pt'><span
  lang=IN style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>  Penerbitan Paspor  Jamaah  Umroh</span></p>
  </td>
  <td width=275 valign=top style='width:206.5pt;padding:0in 5.4pt 0in 5.4pt;
  height:36.95pt'>
  <p class=MsoNormal style='margin-left:8.75pt'><span lang=IN style='font-size:
  12.0pt;line-height:115%;font-family:"Times New Roman",serif;color:black;
  background:white'>Di </span></p>
  <p class=MsoNormal style='margin-left:8.75pt'><span lang=IN style='font-size:
  12.0pt;line-height:115%;font-family:"Times New Roman",serif;color:black;
  background:white'>   </span><span lang=IN style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman",serif;color:black'> </span><span
  lang=IN style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>Kediri</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-left:31.5pt'><span lang=IN style='font-size:
12.0pt;line-height:115%;font-family:"Times New Roman",serif;color:black'>Assalamualaikum
Wr. Wb.</span></p>

<p class=MsoNormal style='margin-left:31.5pt'><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman",serif'>Dengan Hormat,</span></p>

<p class=MsoNormal style='margin-left:31.5pt;text-indent:31.5pt'><span
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>Sehubungan
dengan keberangkatan jamaah umroh kami pada bulan
<?php
function tgl_indo($tanggal){
	$bulan = array (
		1 =>   'Januari',
		'Februari',
		'Maret',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Agustus',
		'September',
		'Oktober',
		'November',
		'Desember'
	);
	$pecahkan = explode('-', $tanggal);
	return $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
?>
<?=tgl_indo($row['jamaah_tgl_berangkat']);?> dengan ini kami beritahukan bahwa :</span></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 width=600
 style='width:6.25in;margin-left:31.25pt;border-collapse:collapse;border:none'>
 <tr style='height:20.75pt'>
  <td width=42 style='width:31.5pt;border:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;
  height:20.75pt'>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>NO.</span></p>
  </td>
  <td width=150 style='width:112.75pt;border:solid black 1.0pt;border-left:
  none;padding:0in 5.4pt 0in 5.4pt;height:20.75pt'>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>NAMA</span></p>
  </td>
  <td width=228 style='width:170.65pt;border:solid black 1.0pt;border-left:
  none;padding:0in 5.4pt 0in 5.4pt;height:20.75pt'>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>TTL.</span></p>
  </td>
  <td width=180 style='width:135.1pt;border:solid black 1.0pt;border-left:none;
  padding:0in 5.4pt 0in 5.4pt;height:20.75pt'>
  <p class=MsoNormal align=center style='text-align:center'><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>ALAMAT</span></p>
  </td>
 </tr>
 <tr style='height:17.0pt'>
  <td width=42 valign=top style='width:31.5pt;border:solid black 1.0pt;
  border-top:none;padding:0in 5.4pt 0in 5.4pt;height:17.0pt'>
  <p class=MsoNormal style='text-align:justify'><b><span lang=IN
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'>1</span></b></p>
  </td>
  <td width=150 valign=top style='width:112.75pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.0pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'><?=$row['jamaah_nama'];?></span></b></p>
  <p class=MsoNormal align=center style='margin-right:14.2pt;text-align:center'><b><span
  lang=IN style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>&nbsp;</span></b></p>
  </td>
  <td width=228 valign=top style='width:170.65pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.0pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'><?=$row['jamaah_tempat_lahir'];?>, <?=tgl_indo($row['jamaah_tanggal_lahir']);?></span></p>
  </td>
  <td width=180 valign=top style='width:135.1pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.0pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
  color:black'><?=$row['jamaah_alamat'];?></span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal style='text-align:justify'><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='margin-left:26.75pt;border-collapse:collapse;border:none'>
 <tr>
  <td width=586 valign=top style='width:439.3pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='text-align:justify'><span style='font-size:12.0pt;
  line-height:115%;font-family:"Times New Roman",serif'>Akan berangkat umroh
  bersama Travel kami PT. Rameyza Wisata Jaya dengan  Izin Umroh No. 456 TH
  2016 yang beralamat di Jl. Joyoboyo Gg. I No. 82 Tepus Kediri.</span></p>
  <p class=MsoNormal style='text-align:justify'><span style='font-size:12.0pt;
  line-height:115%;font-family:"Times New Roman",serif'>Berkaitan dengan hal
  tersebut di atas, bersama ini kami mohon diterbitkan rekomendasi untuk
  pembuatan paspor bagi yang bersangkutan.</span></p>
  <p class=MsoNormal style='text-align:justify'><span style='font-size:12.0pt;
  line-height:115%;font-family:"Times New Roman",serif'>&nbsp;</span></p>
  <p class=MsoNormal style='text-align:justify'><span style='font-size:12.0pt;
  line-height:115%;font-family:"Times New Roman",serif'>Demikian surat ini kami
  buat agar digunakan sebagaimana mestinya. Atas perhatian dan kerjasamanya
  kami sampaikan terimakasih.</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal style='margin-left:31.5pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='margin-left:298.25pt;border-collapse:collapse;border:none'>
 <tr>
  <td width=224 valign=top style='width:167.7pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>Kediri, <?=$row['jamaah_tgl_ttd'];?></span></p>
  </td>
 </tr>
 <tr>
  <td width=224 valign=top style='width:167.7pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
 <tr>
  <td width=224 valign=top style='width:167.7pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><b><u><span style='font-size:12.0pt;line-height:115%;
  font-family:"Times New Roman",serif'>ZAKI ZAMANI, S.STP, MM</span></u></b></p>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>Direktur Utama</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

</div>

</body>

</html>
