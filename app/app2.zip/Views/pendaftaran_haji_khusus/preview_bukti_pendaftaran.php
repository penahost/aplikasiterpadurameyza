<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
    .header {
      display: block;
      margin-left: auto;
      margin-right: auto;
      width: 65%;
    }
    .konten {
        height: 842px;
        width: 595px;
        /* to centre page on screen*/
        margin-left: auto;
        margin-right: auto;
    }
</style>
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	color:black;}
.MsoChpDefault
	{font-family:"Calibri",sans-serif;}
.MsoPapDefault
	{margin-bottom:8.0pt;
	line-height:107%;}
 /* Page Definitions */
 @page WordSection1
	{size:8.5in 14.0in;
	margin:1.0in 1.0in 1.0in 1.0in;}
div.WordSection1
	{page:WordSection1;}
-->
</style>

</head>

<body lang=EN-US style='word-wrap:break-word'>

<div class=WordSection1>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 align=left
 width=816 style='width:8.5in;border-collapse:collapse;border:none;margin-left:
 6.75pt;margin-right:6.75pt'>
 <tr>
  <td width=816 valign=top style='width:8.5in;border:solid windowtext 1.0pt;
  border-bottom:none;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-top:0in;margin-right:-.75pt;margin-bottom:
  5.6pt;margin-left:0in;line-height:normal'><b><span style='font-size:16.0pt'><img
  width=793 height=181 id="Picture 2"
  src="BUKTI%20PENDAFTARAN%20UMROH_files/image001.png"></span></b></p>
  </td>
 </tr>
</table>

<p class=MsoNormal align=center style='margin-top:0in;margin-right:-.75pt;
margin-bottom:5.6pt;margin-left:.5pt;text-align:center;text-indent:-.5pt;
line-height:normal'><b><span style='font-size:16.0pt'>BUKTI PENDAFTARAN UMROH </span></b></p>

<p class=MsoNormal align=center style='margin-top:0in;margin-right:-.75pt;
margin-bottom:5.6pt;margin-left:.5pt;text-align:center;text-indent:-.5pt;
line-height:normal'><b><span style='font-size:16.0pt'>PT.RAMEYZA WISATA JAYA </span></b></p>

<p class=MsoNormal align=center style='margin-top:0in;margin-right:-.75pt;
margin-bottom:5.6pt;margin-left:.5pt;text-align:center;text-indent:-.5pt;
line-height:normal'>&nbsp;</p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none'>
 <tr>
  <td width=186 valign=top style='width:139.25pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>NAMA JAMAAH</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>NIK</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>JENIS IDENTITAS</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>TEMPAT,TANGGAL LAHIR</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>ALAMAT</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>JENIS KELAMIN</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>KEWARGANEGARAAN</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>DESA/KELURAHAN</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>KECAMATAN</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>KOTA/KABUPATEN</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>NOMOR TELEPON</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>PAKET PILIHAN</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>RENCANA BERANGKAT</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>BIAYA UMRAH</span></b></p>
  </td>
  <td width=438 valign=top style='width:328.25pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Rony</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: 12345</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: KTP</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: KEDIRI, 17 Januari 1996</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Nganjuk</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Laki-laki</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Indonesia</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Nganjuk</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Nganjuk</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Nganjuk</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: 086566766</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Paket umrah 12 Hari</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: Tanggal 12</span></b></p>
  <p class=MsoNormal style='line-height:150%'><b><span style='font-size:12.0pt;
  line-height:150%'>: 500000</span></b></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><b>&nbsp;</b></p>

<p class=MsoNormal><b>&nbsp;</b></p>

<p class=MsoNormal><b>&nbsp;</b></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=624
 style='width:467.75pt;border-collapse:collapse;border:none'>
 <tr>
  <td width=186 valign=top style='width:139.25pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  </td>
  <td width=234 valign=top style='width:175.5pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  </td>
  <td width=204 valign=top style='width:153.0pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><img width=113
  height=138 id="Picture 1" src="BUKTI%20PENDAFTARAN%20UMROH_files/image002.png"></b></p>
  </td>
 </tr>
 <tr>
  <td width=186 valign=top style='width:139.25pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>Tanggal</b></p>
  </td>
  <td width=234 valign=top style='width:175.5pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  </td>
  <td width=204 valign=top style='width:153.0pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  </td>
 </tr>
 <tr>
  <td width=186 valign=top style='width:139.25pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>PETUGAS</b></p>
  </td>
  <td width=234 valign=top style='width:175.5pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  </td>
  <td width=204 valign=top style='width:153.0pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>CALON JAMAAH
  UMRAH</b></p>
  </td>
 </tr>
 <tr>
  <td width=186 valign=top style='width:139.25pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>…………………………….</b></p>
  </td>
  <td width=234 valign=top style='width:175.5pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  </td>
  <td width=204 valign=top style='width:153.0pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>&nbsp;</b></p>
  <p class=MsoNormal align=center style='text-align:center'><b>……………………………….</b></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><b>&nbsp;</b></p>

</div>

</body>

</html>
