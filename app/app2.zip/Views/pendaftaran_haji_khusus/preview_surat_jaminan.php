<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
    body {
        height: 842px;
        width: 595px;
        /* to centre page on screen*/
        margin-left: auto;
        margin-right: auto;
    }
</style>
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:.5in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:.5in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:.5in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:.5in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
.MsoChpDefault
	{font-family:"Calibri",sans-serif;}
.MsoPapDefault
	{margin-bottom:10.0pt;
	line-height:115%;}
 /* Page Definitions */
 @page WordSection1
	{size:595.35pt 841.95pt;
	margin:83.85pt 56.7pt 28.35pt 56.7pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
 ol
	{margin-bottom:0in;}
ul
	{margin-bottom:0in;}
-->
</style>

</head>

<body lang=EN-US style='word-wrap:break-word'>

<div class=WordSection1>

<p class=MsoNormal align=center style='text-align:center'><b><u><span
style='font-size:18.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>SURAT JAMINAN</span></u></b></p>

<p class=MsoNormal align=center style='text-align:center'><b><u><span
style='font-family:"Times New Roman",serif;color:black'><span style='text-decoration:
 none'>&nbsp;</span></span></u></b></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif;color:black'>Dengan hormat,</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif;color:black'>Yang bertanda tangan dibawah ini :</span></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='margin-left:8.75pt;border-collapse:collapse;border:none'>
 <tr>
  <td width=78 valign=top style='width:58.5pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:12.0pt;
  font-family:"Times New Roman",serif;color:black'>Nama</span></p>
  </td>
  <td width=552 valign=top style='width:414.2pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:12.0pt;
  font-family:"Times New Roman",serif;color:black'>:</span><span
  style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'> </span><span
  style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'> </span><span
  lang=IN style='font-size:12.0pt;font-family:"Times New Roman",serif;
  color:black'>ZAKI ZAMANI</span></p>
  </td>
 </tr>
 <tr>
  <td width=78 valign=top style='width:58.5pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:12.0pt;
  font-family:"Times New Roman",serif;color:black'>Alamat</span></p>
  </td>
  <td width=552 valign=top style='width:414.2pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:12.0pt;
  font-family:"Times New Roman",serif;color:black'>: </span><span lang=IN
  style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>Jl.
  Joyoboyo Gang 1/82 Tepus - Kediri</span></p>
  </td>
 </tr>
 <tr>
  <td width=78 valign=top style='width:58.5pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:12.0pt;
  font-family:"Times New Roman",serif;color:black'>Jabatan</span></p>
  </td>
  <td width=552 valign=top style='width:414.2pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:12.0pt;
  font-family:"Times New Roman",serif;color:black'>: </span><span lang=IN
  style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>Direktur
  Utama PT.</span><span lang=IN style='font-size:12.0pt;font-family:"Times New Roman",serif;
  color:black'> </span><span lang=IN style='font-size:12.0pt;font-family:"Times New Roman",serif;
  color:black'>Rameyza Wisata Jaya</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><b><u><span lang=IN style='font-family:"Times New Roman",serif;
color:black'><span style='text-decoration:none'>&nbsp;</span></span></u></b></p>

<p class=MsoNormal style='text-indent:14.2pt'><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman",serif;color:black'>Menerangkan
bahwa :</span><span style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'> </span></p>

<p class=MsoNormal style='text-indent:14.2pt'><span lang=IN style='line-height:
115%;font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoNormal align=center style='text-align:center'><b><span
lang=IN style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'><?=$row['jamaah_nama'];?>
</span></b></p>

<p class=MsoNormal style='margin-left:1.5in;text-indent:.5in'><span lang=IN
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>&nbsp;</span></p>

<p class=MsoNormal style='text-indent:25.1pt'><span lang=IN style='font-size:
12.0pt;line-height:115%;font-family:"Times New Roman",serif;color:black'>Menyatakan
: </span></p>

<p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoListParagraphCxSpFirst style='margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:43.1pt;text-indent:-.25in;line-height:normal'><span
lang=IN style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>1.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
lang=IN style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>Memberikan
rekomendasi membuat paspor untuk keberangkatan umroh melalui </span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:43.1pt;line-height:normal'><span lang=IN
style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>PT.
Rameyza Wisata Jaya</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:43.1pt;text-indent:-.25in;line-height:normal'><span
lang=IN style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>2.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
lang=IN style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>Menjamin
bahwa calon jamaah umroh tersebut diatas tidak akan melakukan pelanggaran
peraturan keimigrasian berupa penyalahgunaan izin tinggal, tinggal melebihi
izin tinggalnya (overstay), memalsukan atau membuat palsu paspor yang diberikan
kepadanya maupun bekerja secara  ilegal.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:43.1pt;text-indent:-.25in;line-height:normal'><span
style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>3.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;font-family:"Times New Roman",serif;color:black'>Menjamin
dan bertanggung jawab terhadap keberangkatan dan kembalinya jamaah umroh ke
tanah air.</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoNormal style='text-indent:14.2pt'><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman",serif;color:black'>Bahwa nama
diatas benar-benar akan berangkat umroh bersama PT.  </span><span lang=IN
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>Rameyza Wisata Jaya</span><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman",serif;color:black'> dan tidak
akan melakukan kesalahan dengan menyalahgunakan paspor dengan izin tinggal
melebihi ketentuan yang sudah ada. </span></p>

<p class=MsoNormal style='text-indent:14.2pt'><span lang=IN style='font-size:
12.0pt;line-height:115%;font-family:"Times New Roman",serif;color:black'>Atas </span><span
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>perhatian dan kerjasamanya kami sampaikan terima kasih.</span></p>

<p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
font-family:"Times New Roman",serif;color:black'>Kediri, </span><span
lang=IN style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>10 Februari 2021</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif;color:black'>PT.  </span><span lang=IN
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>Rameyza Wisata Jaya</span></p>

<p class=MsoNormal><span lang=IN style='font-size:12.0pt;line-height:115%;
font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoListParagraphCxSpFirst align=center style='margin-left:0in;
text-align:center'><span style='color:black'>&nbsp;</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:0in'><span lang=IN
style='color:black'>&nbsp;</span></p>

<p class=MsoListParagraphCxSpMiddle align=center style='margin-left:0in;
text-align:center'><span lang=IN style='font-size:12.0pt;line-height:115%;
font-family:"Times New Roman",serif;color:black'>&nbsp;</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:0in'><b><u><span
lang=IN style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>ZAKI ZAMANI, S.STP, MM</span></u></b></p>

<p class=MsoListParagraphCxSpLast style='margin-left:0in'><span
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif;
color:black'>Direktur Utama</span></p>

</div>

</body>

</html>
