<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
    body {
        height: 842px;
        width: 595px;
        /* to centre page on screen*/
        margin-left: auto;
        margin-right: auto;
    }
</style>
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:.5in;
	line-height:115%;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:.5in;
	line-height:115%;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:.5in;
	line-height:115%;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:.5in;
	line-height:115%;
	font-size:12.0pt;
	font-family:"Times New Roman",serif;}
.MsoChpDefault
	{font-family:"Calibri",sans-serif;}
.MsoPapDefault
	{margin-bottom:8.0pt;
	line-height:107%;}
@page WordSection1
	{size:8.5in 11.0in;
	margin:1.0in 1.0in 1.0in 56.9pt;}
div.WordSection1
	{page:WordSection1;}
-->
</style>

</head>

<body lang=EN-US style='word-wrap:break-word'>

<div class=WordSection1>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none'>
 <tr>
  <td width=84 valign=top style='width:62.75pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
  <td width=345 valign=top style='width:258.95pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
  <td width=215 valign=top style='width:160.9pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>&nbsp;</span></p>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>Kepada
  :</span></p>
  </td>
 </tr>
 <tr>
  <td width=84 valign=top style='width:62.75pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>Nomor</span></p>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>Lampiran</span></p>
  </td>
  <td width=345 valign=top style='width:258.95pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>: </span></p>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>: -</span></p>
  </td>
  <td width=215 valign=top style='width:160.9pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>Yth.
  Kepala Imigrasi kediri</span></p>
  </td>
 </tr>
 <tr>
  <td width=84 valign=top style='width:62.75pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>Perihal</span></p>
  </td>
  <td width=345 valign=top style='width:258.95pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
  "Times New Roman",serif'>: Penerbitan Paspor  Jamaah  Umroh</span></p>
  </td>
  <td width=215 valign=top style='width:160.9pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>Di
  kediri</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal style='margin-left:45.0pt;text-align:justify;text-indent:
31.5pt'><span style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'>Berkaitan
dengan keberangkatan umroh jamaah kami di bulan
<?php
echo $row['jamaah_tgl_berangkat'];
?>, dengan ini kami
mohon untuk dapat dibuatkan paspor dengan 3 (tiga) buah suku kata untuk jamaah 
kami sebagaimana tersebut dibawah ini yaitu :</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal align=center style='text-align:center'><b><span
style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman",serif'><?=$row['jamaah_nama'];?>
</span></b></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal style='margin-left:45.0pt'><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman",serif'>Demikian untuk menjadi
maklum dan atas kerjasamanya disampaikan terima kasih.</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='margin-left:255.3pt;border-collapse:collapse;border:none'>
 <tr>
  <td width=275 valign=top style='width:206.45pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoListParagraph align=center style='margin-top:0in;margin-right:
  7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><span
  style='color:black'>PT. </span><span lang=IN style='color:black'>Rameyza
  Wisata Jaya</span></p>
  </td>
 </tr>
 <tr>
  <td width=275 valign=top style='width:206.45pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoListParagraphCxSpFirst align=center style='margin-top:0in;
  margin-right:7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><span
  style='color:black'>&nbsp;</span></p>
  <p class=MsoListParagraphCxSpMiddle align=center style='margin-top:0in;
  margin-right:7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><span
  style='color:black'>&nbsp;</span></p>
  <p class=MsoListParagraphCxSpMiddle align=center style='margin-top:0in;
  margin-right:7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><span
  style='color:black'>&nbsp;</span></p>
  <p class=MsoListParagraphCxSpMiddle align=center style='margin-top:0in;
  margin-right:7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><span
  style='color:black'>&nbsp;</span></p>
  <p class=MsoListParagraphCxSpLast align=center style='margin-top:0in;
  margin-right:7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><span
  style='color:black'>&nbsp;</span></p>
  </td>
 </tr>
 <tr>
  <td width=275 valign=top style='width:206.45pt;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoListParagraphCxSpFirst align=center style='margin-top:0in;
  margin-right:7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><b><u><span
  lang=IN style='color:black'>ZAKI ZAMANI, S.STP, MM</span></u></b></p>
  <p class=MsoListParagraphCxSpLast align=center style='margin-top:0in;
  margin-right:7.1pt;margin-bottom:10.0pt;margin-left:0in;text-align:center'><span
  lang=IN style='color:black'>Direktur Utama</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><span style='font-size:12.0pt;line-height:115%;font-family:
"Times New Roman",serif'>&nbsp;</span></p>

</div>

</body>

</html>
